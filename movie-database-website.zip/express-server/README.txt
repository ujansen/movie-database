Project: Movie Database

Partners: Ujan Sen      (101171605)
          Meera Balsara (101152760)


=> A summary of any extensions you have added to your system:

1. Bootstrap
- Front-end framework that greatly enhanced the aesthetic appeal of the website
- Helped with creation of navbar, forms, card-blocks among other elements

2. Web scraping
- Implemented webpage automation and web scraping using puppeteer and asynchronous functions
- Users can type in a movie's title and the web scraper searches for the movie on IMDB and scrapes appropriate data

3. Extensive testing of API with Postman
- Tested each and every specific route by passing in valid as well as invalid requests to ensure efficacy
- A much more detailed report on API testing will be presented along with final submission

- Note: A database will be incorporated in the final submission :)

=> A summary of any design decisions you feel have increased the quality of your system:

- Guest users are supported and have the following permissions:
	- can search, access, and view movie and person pages
	- can submit basic reviews for movies (i.e. only rating)
	- can test out our web scraping functionality (search IMDB)
- We are storing IDs of movies, people, users, and reviews inside the sample data to reduce redundancy
- Trailers are embedded in the movie page (our test data does not currently contain trailer links, but when a movie is added/edited, trailer and movie poster links can be supplied)
- Users can upload profile pictures in edit user (after registering) if they choose to do so
- Movies are recommended to users based on the movies they have already reviewed since they are likely to watch movies with (more than two) common genres
- User can only view another user's follower and following lists if the user follows them (popular social media platforms such as facebook and instagram implement this, hence we decided to implement this)
- Multiple sessions have been taken care of, users can interact with each other without any issues (can test by logging in in a normal window and an incognito window)
- Users cannot edit their own information without entering their old password correctly

=> Your OpenStack instance information, including its public IP address (134.117.x.y) and username/password: 
- public IP address: 134.117.133.3
- username: student (meerabalsara)
- password: cinnamontoast

=> Instructions to the TA specifying how to initialize and run your server on the OpenStack instance. 
- To run the server:
	1. Log in
	2. Enter the movie-database folder: cd movie-database
	3. Start the server: node movie-server.js
- To reset the server to its original state:
	- Stop the server (ctrl + c) and run it again using step 3 from above
	(this is because a database has not been incorporated yet and data from RAM is currently being used)

Notes: 
- Dependencies have been installed (in /home/student)
- Movies without posters show up as tiny grey boxes on the image sliders
- Frequent collaborators has not been implemented yet but will soon be